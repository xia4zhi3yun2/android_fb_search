package com.example.xia4z.searchonfb;

/**
 * Created by xia4z on 4/25/2017.
 */

public class Post_item {
    private String time,post;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }
}
